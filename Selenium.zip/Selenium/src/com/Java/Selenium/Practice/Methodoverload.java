package com.Java.Selenium.Practice;

public class Methodoverload {

    public static void main(String[] args) {
    Methodoverload obj=new Methodoverload();
    obj.sum();
    obj.sum(10);
    obj.sum(10,20);
    obj.sum1();
    obj.sum2();

    }
    public void sum1(){
        System.out.println("method1");
    }

    public void sum2(){   //we cant create same parameters and
        // same name methods but we can create same name with parameters
        System.out.println("method2");
    }

    public void sum(){
        System.out.println("method zero parameters");
    }

    public void sum(int i){   //we cant create same parameters and
        // same name methods but we can create same name with parameters
        System.out.println("method with 1 parameter");
    }

    public void sum(int j,int k){   //we cant create same parameters and
        // same name methods but we can create same name with parameters
        System.out.println("method with 2 parameter");
    }

    //this concept  method overloading is called when the method name is same with different arguments or no of input parameters or differnt datatypes with in the same class
    //we cant create a method inside the method
    //same method name with same no of parameters and same datatypes are not allowed
    //main method ca be overloaded?--yes we can overload main method although we cant do that but yes can be over load





}
