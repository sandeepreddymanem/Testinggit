package com.Java.Selenium.Practice;         //Defining the Package

public class Main {                 //Class

      public static void main(String[] args) {    //Method--Main method is already defined
                // write your code here
                System.out.println("Starting Point of Execution");  //Main is the heart and the starting point for execution without this cant execute
//Always save file with extension .java like .xls,.txt
                //Singe characters goes into 'a','A'etc..Not more than one is not allowed
                //Int
                //Double
                //Boolean-True/False Values and these is also keywords available in Java
                //String is not Datatype,It is a class,We can use as a Datatype
                //Primitive Data types-Integer,char,Boolean,Double
                //String-Is not Primitive datatype,it is a class
                int a = 1;
                int b = 2;
                String c = "First";
                String d = "Second";
                Double e = 10.1;
                Double f = 20.6;
                //String concatination
                System.out.println(a+b);
                System.out.println(a+b+e+f);
                System.out.println(a+b+c+d+e+f);
                System.out.println(c+d+a+b+e+f);
                System.out.println(c+d);
                System.out.print(c);        // without 'ln' no print on new line and print on same line
                System.out.print(d);        //this is difference between println and print- new line and same line printing
                //comparision operators
                //simple comparision
                //if--else loop
                int i=10;
                int j=20;
                if (i<j) {      //if(condition){}else{}
                    System.out.println("i is less than j");
                }else
                {   System.out.println("i is greater than j");
                }

                //>,<,<=,>=,!=,==
                //& and

                //if --else loop
                int k=20;
                int l=20;
                if (l==k) {
                    System.out.println("k is equal to l");
                }else
                {   System.out.println("k is not equaal to l");

                }

                //While loop
                //disadvantage in while loop is it will give infinite loop if we miss increment/decrement condition
                int x=10;
                int y=20;
                while(x<=y) {
                    System.out.println("while loop "+x);
                    x++;
                }

                //for loop
                int xx=10;
                int yy=20;

                for (xx=10;xx<=yy;xx++){   // we cant increase 2 by x++ ++ it is not allowed
                    System.out.println("for loop using xx++" + x);
                }

                //  or
                yy=30;
                // cant use this condition  y=y+1;
                for (xx=10;xx<=50;xx=xx+1){
                    System.out.println("for loop using xx+1 " + xx);
                }

                //print 10 to -10

                for (int gg=10;gg>=-10;gg--){   // we cant increase 2 by x++ ++ it is not allowed
                    System.out.println("for loop using xx-- =" + gg);
                }

                //Increment and Decrement
                //Increment ++
                //Decrement --
                int hh=1;
                int mm=hh++;  //post increment //get the value of hh and given to mm then icrment by 1 now the value of h is 2
                System.out.println(hh);  //2 as its increment by 1 because of post increment in mm
                System.out.println(mm); //1 it got value of hh then incremented by 1
                hh=5;
                mm=++hh;  //pre increment //get the value of hh increment by 1 so the value of hh is 6 and same is stored
                System.out.println(hh);  //6 as its increment by 1 because of post increment in mm
                System.out.println(mm); //6 it got value of hh then incremented by 1

                hh=10;
                mm=hh--;  //post decremnent //get the value of hh and given to mm then decrment by 1
          // now the value of h is 9
          System.out.println(hh);  //9 as its increment by 1 because of post decrement in mm
          System.out.println(mm); //10 it got value of hh then decrement by 1
          hh=5;
          mm=--hh;  //pre increment //get the value of hh decrement by 1 so the value of hh is 6 and same is stored
          System.out.println(hh);  //4 as its decrement by 1 because of post decrement in mm
          System.out.println(mm); //4 it got value of hh then decrement by 1

          //Array Variables --to store similar data values in array
          //Int array  //one dimensional array  //store only similar datatypes
          int s[] = new int[4];  //n=size of array
          s[0]=10;   //lower bound/index is 0
          s[1]=20;
          s[2]=30;
          s[3]=40;   //upper bound/index is n-1


          System.out.println(s[1]); //20
          System.out.println(s[3]); //40
         // System.out.println(s[4]);  //if try to access s[4] then error with execption ArrayIndexOutOfBoundsException
          System.out.println(s.length);  //to know size/length of array  //this is static

          //Print all the values in Array then use loop
          for (int o=0;o<s.length;o++) {
              System.out.println(s[o]);
          }
          //Size is fixed--Here disadvantage is Size of array is fixed and I cant go beyond the defined value
          //To overcome this disadvantage we use collections --Array list,Hashtable and these are also called dynamic arrays
          //Advantage is instead of storing the values in multiple variables we can store the same in Array single variable.


          double darray[]= new double[4];
          darray[0]=0.5;
          darray[1]= 1.5;
          darray[2]=2.5;
          darray[3]=3.5;
          System.out.println(darray[2]);

          char carray[]= new char[4];
          carray[0]='a';
          carray[1]= 'b';
          carray[2]='c';
          carray[3]='d';


          boolean barray[]= new boolean[4];
          barray[0]=true;
          barray[1]= false;


          String sarray[]= new String[4];
          sarray[0]="Hello";
          sarray[1]="How";
          sarray[2]="Are";
          sarray[3]="You";


          //How to Store different datatypes in a single variable --to overcome this problem we use object array
          //Object array--Object is a class
          Object obj[]=new Object[4];
          obj[0]="tom";
          obj[1]=100;
          obj[2]=800.55;
          obj[3]='M';

          System.out.println(obj[3]);
          //Object array is used to store different data type values
          //for all th array values use for loop always
          // below is two dimensional array concept
          //row.column-3x4 matrix-2D array
    //      0     1     2   3
    //  0   0.0  0.1  0.2  0.3
    //  1   1.0  1.1  1.2  1.3
    //  2   2.0  2.1  2.2  2.3

          //how to create 2d array
          String zz[][]=new String[3][4];

          System.out.println(zz.length);  //this will give total no of rows
          System.out.println(zz[0].length);  //to get total no of columns -here pick row and get length which is same for all rows

          //to store the values
          zz[0][0]="A";
          zz[0][1]="B";
          zz[0][2]="C";
          zz[0][3]="D";
          zz[1][0]="A1";
          zz[1][1]="B1";
          zz[1][2]="C1";
          zz[1][3]="D1";
          zz[2][0]="A2";
          zz[2][1]="B2";
          zz[2][2]="C2";
          zz[2][3]="D2";

          //A  B  C  D
          //A1 B1 C1 D1
          //A2 B2 B2 D2

          System.out.println(zz[2][1]);
          System.out.println(zz[0][3]);
//print all values of 2d array

          for (i=0;i<zz.length;i++){  //rows
              for (j=0;j<zz[0].length;j++){ //columns

                  System.out.println(zz[i][j]);
              }

          }

//in selenium this is helpful to store the data in excel or read from excel

          //writing a[] or []a both same
          //similarly a[][] or [][]a both same

//OOPS CONCEPTS

//CLASS is a entity where we can define properties by defining no of methods and variables
// variable and methods are characterstics of class
          //refer new class OOPS1 class
            OOPS1 objectofOOPS1 =new OOPS1();
          objectofOOPS1.printgreet();  //only we can only access all non static methods once we create object
         int n= objectofOOPS1.division(4,2); //here we cant access static methods
         int m= objectofOOPS1.add();//so we cant access static in OOPS1 only non static from OOPS1
          System.out.println(n+m);


          //why main method is void ?- because it will never returns a value








            }

        }


