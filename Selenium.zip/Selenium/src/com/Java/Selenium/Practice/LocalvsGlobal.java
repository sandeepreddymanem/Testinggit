package com.Java.Selenium.Practice;

public class LocalvsGlobal {
    String name="sunny";  //class or global variable
    int age=1234; //class or global variable //immediately after the class


    public static void main(String[] args) {
        int i=100; // this is local variables of main method
        System.out.println(i);
        //System.out.println(name);
        // we cant access as name is global variable
        // so to access the same we have to create object of the class(Localvs Global)
        // we can only access non static variables/methods
        LocalvsGlobal LvsG = new LocalvsGlobal();
        System.out.println(LvsG.name); // this is how we can access global variables
    }

    public void sum(){
        int i=99;//local variable of sum method
        int j=109;//local variable
        int age=20; //local variable
        System.out.println(i);
    }

}
