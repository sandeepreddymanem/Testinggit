package com.Java.Selenium.Practice;

public class OOPS1 {

    int mod;   //class varibles/global variables
    int wheel;  //class varibles/global variables

    public static void main(String[] args) {
        OOPS1 a = new OOPS1();  //reprents a object  of OOPS1 class
        // --a is object reference variable
        // new car is called object with this line one object creates in java memory with refernce a
        // how to create object? --we create object by using new operator/new keyword
        OOPS1 b = new OOPS1(); //here a,b,c are representing objects but these are not objects.new OOPS1 is the object
        OOPS1 c = new OOPS1();  //we cant create duplicate objects so we cant create a object again

        //so now all the 3 objects will have mod and wheels variables in it

        a.mod = 2015;  //this is initialising variables
        a.wheel = 4;

        b.mod = 2016;
        b.wheel = 4;

        c.mod = 2017;
        c.wheel = 4;

        System.out.println(a.mod);
        System.out.println(a.wheel);
        System.out.println(b.mod);
        System.out.println(b.wheel);
        System.out.println(c.mod);
        System.out.println(c.wheel);
        //changing reference
        a = b;
        b = c;
        c = a;

        //1st object no one refering from a
        //2nd object refering a,c from b
        //3rd object refering b from c
        a.mod = 10;
        System.out.println(a.mod);//10
        c.mod = 20;
        System.out.println(a.mod); //20 // because of refering c and a reference same objects

        //this is called shift of object reference from one object to another object



    }
    //Funtions/methods  -Functions and methods are same dont confuse
    //non static method
    //we are creating methos otside of main and we call this methos when ever required in main method
//no input no output
    public void printgreet() {  //void means not returning anything
        System.out.println("printing method");
    }

    //no input some output
    public int add() {  //return type is int
        System.out.println("addition");
        int aa = 1;
        int bb = 3;
        int ccadd = aa + bb;
        return ccadd;
    }

    public String objectout(){  //return type is string
        System.out.println("objectout method");
        String s=new String();
        return s;
    }

    //input something ,output some thing
    public int division(int x,int y){
        System.out.println("division");
       int d=x/y;
        return d;
    }
}