package com.Java.Selenium.Practice;

public class Inheritance {
    public static void main(String[] args) {
        //parent cant inherit from child
        //child can inherit from parents
        //parent can have no of children
        //child cannot have multiple parents

                //parent class or super class
                //child class or sub class
        //by default all the child class will inherit all the methods of parent class
        //this is called extending the property--extends
        //Science-->Physics-->Engineering-->Mechanical-->Automobile--->Vehicle---->car  -->bmw,audi,honda
       //Physics is extending Science and Engineering extending Physics.....bmw is extending car
        // BMW can inherit prperties from all(Science,Physics,Engineering,Mechanical,Automobile,Vehicle,car)

           }
}
