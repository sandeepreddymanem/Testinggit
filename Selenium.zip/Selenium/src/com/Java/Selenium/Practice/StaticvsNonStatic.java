package com.Java.Selenium.Practice;

public class StaticvsNonStatic {
    String name="sunny";  //non static global variable
    static int age = 30; //static global variable

    public static void main(String[] args) {

        //how to call static methods
        //1.direct calling
        sum();
        //2.calling by classname
        StaticvsNonStatic.sum();//to access static method
        System.out.println(StaticvsNonStatic.age); //to access static global variables
        //static variables are not part of object,all static will have saperate memory allocation.
        //to acess non static
        StaticvsNonStatic obj = new StaticvsNonStatic();
        System.out.println(obj.name);
        obj.sendmail();
        //can i access static method by using obj reference--answer is yes i can access but it will give warning stating that you canuse static
        obj.sum(); //warning will be given and no need to use object we can access directly
        sum();//like this directly we can access

        }

        public void sendmail(){  //non static method  //how to access non static by creating object
            System.out.println("send mail method");
        }
    public static void sum(){  //static method
        System.out.println("sum method");
    }


}
