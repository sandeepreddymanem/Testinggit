package com.Java.Selenium.Practice;

public class TestCar {

    public static void main(String[] args) {

        BMW carbmw=new BMW();
        carbmw.start();  //thi is own method from bmw but same name in parent is overridden
        //this is method overriding
        // when ever method is same in parent and child class
        // then the preference is child class
    //this is methodoverriding--when same method prent in parent and child
        // with same name,datatype and same no of argumentsis called method overriding
        //preference will be given to overridden method
    carbmw.stop(); //inherited from parent/super class
    carbmw.refuel();  //inherted from super class
    carbmw.keysafety(); //it is own method of bmw not inherited
        //All the above is called compile time polimorism/static polymorpism
        //polymorpism means one to many methods //method overriding
        System.out.println("********************");
        Car c=new Car();
        c.start();
        c.stop();
        c.refuel();
        //c.keysafety(); //we cant access as it is BMW property.cant inherit child property

        new BMW();  //obj created without any reference
        Car c1=new BMW(); //child class object can be refered by parent class reference variable --Dynamic polymorpism/runtime polymorpism
        c1.start();//from bmw
        c1.stop();//from car
        c1.refuel();//from car
        //c1.keysafety() //we cant access this bmw method/child method
        // we can refere bmw object but we cant access my properties so only common overridden methods and parent
        //class methods can be called using dynamic polymorpism

        //Top Casting means fitting the child in parent as above
        Car c3= new BMW();  //Dynamic ploymorpism
        //Down Casting
        //BMW b3=new Car();  //this is not pssible cant fit parent in child
        BMW b3=(BMW) new Car(); //run time it will classcasting exception at runtime

        //Inheritence,Compiletime/static Poly(Method Overriding),Runtime/Dynamic Poly(child class refred by parent refer var),Top Casting,Down Casting
        //by dynamic ply--overriden method can be called and parent method can be called



    }
}
