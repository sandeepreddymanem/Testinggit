package com.Java.Selenium.Practice;


public class CallbyValCallbyRef {
    int p;
    int q;
    public static void main(String[] args) {

        CallbyValCallbyRef obj=new CallbyValCallbyRef();
        obj.testsum(10,20); //this is calling directly parsing the value
        int x=20;
        int y=30;
        int xyz=obj.testsum(x,y);//this is callbyvalue we are parsing copy values instead of direct copies
        System.out.println(xyz);
        System.out.println(x); //there is no change in value of x
        System.out.println(y); //there is no change in value of y
obj.p=33;
obj.q=66;
        System.out.println(obj.p);
        System.out.println(obj.q);
obj.swap(obj); //this call by reference

        System.out.println(obj.p);
        System.out.println(obj.q);
    }

    public int testsum(int i, int j) {
        i=50;
        j=60;
        int c = i + j;
        return c;
    }
//is it possible call by reference in java --yes it is possible by passing object reference
    public void swap(CallbyValCallbyRef cbvcbr){ //this is call by reference which is same as pointers in c.,we are  passing and calling by object reference
        int temp;
        System.out.println(cbvcbr.p);
        System.out.println(cbvcbr.q);
        temp= cbvcbr.p; //33
        cbvcbr.p=cbvcbr.q; //66
        cbvcbr.q=temp; //33
        System.out.println(cbvcbr.p);
        System.out.println(cbvcbr.q);

    }
}
