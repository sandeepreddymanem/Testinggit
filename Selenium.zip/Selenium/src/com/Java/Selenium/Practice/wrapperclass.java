package com.Java.Selenium.Practice;

public class wrapperclass {
    public static void main(String[] args) {

        String x= "100";
        System.out.println(x+20);
        //we convert string to int
        int i=Integer.parseInt(x);
        //here x value converted and given to i(string to integer)
        System.out.println(i+20);

        String y="1.56";
        System.out.println(y+1);
        double d=Double.parseDouble(y);
        System.out.println(d+1);

        String z="true";
        System.out.println(z);
        boolean b=Boolean.parseBoolean(z);
        System.out.println(b);

        //int to string
        int j=200;
        System.out.println(j+122);
        String s=String.valueOf(j);
        System.out.println(s+122);

        //what will happen if you give 100a value anf try to convert from string to int
        String u="100A";
        int ii=Integer.parseInt(u);
        System.out.println(ii); //this will give number format exception

        // all this Integer,Double,Boolean are wrapperclasses for data conversion


    }
}
