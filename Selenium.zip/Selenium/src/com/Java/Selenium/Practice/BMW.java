package com.Java.Selenium.Practice;

public class BMW extends Car{ //to build any relationship between two classes we have to use extends
    //here bmw can inheriting properties from car class
    //to make any releationship between two classes then use extends keyword


    public void start() {
        System.out.println("BMW start");
    }

    public void keysafety(){
        System.out.println("Key less entry for BMW");
    }
}
